import axios from "axios";

const API_URl = "https://donjjewellery.com/wp-json/nivoda/get_diamond";


 
 fetchDataCetagoryWise(){
    const form = new FormData();
    form.append('smartphones', 'smartphones')
    form.append('laptops', "laptops")
    form.append('fragrances',  'fragrances')
    form.append('skincare',  'skincare')
    form.append('groceries',  'groceries')
    return axios({url: API_URl ,method: "POST",data: form})
}

export default fetchDataCetagoryWise;


  
  