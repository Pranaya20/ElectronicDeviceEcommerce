import styled from "styled-components";

export const Wrapper = styled.div`
.option-div{
   
    bottom:5px;
    display:flex;
    .option-box-div{
        position:relative:
        width:100%;
        .presentation-image{
            top:-142px;
            font-size: 12px;
            pointer-events: auto;
            margin: auto auto 15px;
            z-index:999;
            position:relative;
            max-width:130px;
            width: auto;
            letter-spacing: 0.1em;
            padding: 14px 16px;
            background:#ffffff;
            color:#000000;
            display:flex;
            align-items:center;
            justify-content:center;
        }
        .presentation-image:hover{
            background:rgb(38, 38, 38);
            color:rgb(255, 255, 255);
            cursor:pointer;
        }
        .option-image-div{
            width:100%;
            // position:relative;
        }
    }   
}
@media (min-width:320px) and (max-width:767px){
    .option-div{
        .option-box-div{
            .presentation-image{
                top:0px !important;
            }
        }  
    } 
}
`;