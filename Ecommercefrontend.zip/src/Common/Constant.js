 import ShopDress from "../Assets/Image/demo2.jpg";
 import ShopTees from "../Assets/Image/demo4.jpg";
 import ShopBottoms from "../Assets/Image/demo3.jpg";
 import ShopTops from "../Assets/Image/demo1.jpg";
 import ShopDenims from "../Assets/Image/demo6.jpg";
 import ShopAcessories from "../Assets/Image/demo9.jpg";
 import ShopSwim from "../Assets/Image/demo5.jpg";
 import ShopSkirts from "../Assets/Image/demo7.jpg";

export const SHOPITEMS = [
    { id: 1, images: ShopDenims, name: "SHOPE DENIMS" },
    { id: 2, images: ShopAcessories, name: "SHOPE ACESSORIES" },
    { id: 3, images: ShopSwim, name: "SHOPE SWIM" },
    { id: 4, images: ShopSkirts, name: "SHOPE SKIRTS" }, 
];

 export const NAVDATA = [{id:1,name:'Women'}, {id:2,name:'Men'}, {id:3,name:'About'}, {id:4,name:'everworld stories'} ];
 export const SUBNAVDATA = [{id:1,name:'What s New'},{id:2, name:'Best-Sellers'},{id:3, name:'Apparel'},{id:4, name:'Denim'},{id:5, name:'Shoes, Bages & Accessories'}, {id:6, name:'sale'}];
 export const COLORS = ["rgb(0, 0, 0)", "rgb(159, 154, 137)", "rgb(135, 79, 59)"];
 export const COLLECTION = "The Dress Collection";
 export const STYLE = "Your occasions. Your style.";
 export const EVERPIECE = "Forever pieces-to wear on repeat.";
 export const OFFERMESSAGE = " New summer suiting, instant outfit-makers. Shop Suiting Now";

 export const PRESENTOPTION = [
    { id: 1, images: ShopDress, name: "SHOPE SMARTPHONES", redirect:"/smartphones/" },
    { id: 2, images: ShopTees, name: "SHOPE LAPTOPS", redirect:"" },
    { id: 3, images: ShopBottoms, name: "SHOPE FRAGRANCES", redirect:"" },
    { id: 4, images: ShopTops, name: "SHOPE SKINCARE", redirect:"" },
  ];

 