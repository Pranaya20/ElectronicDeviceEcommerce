import LandingPage from "./View/LandingPage";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import NavbarOffer from "./Components/NavbarOffer";
import Navbar from "./Components/Navbar";
import WomenGarments from "./View/WomenGarments";
import Image from "../src/Assets/Image/dress1.jpg";

function App() {
  return (
    <div>
      <Router>
        <NavbarOffer/>
        <Navbar/>
        <Routes basename="/">
          <Route path="/" element={<LandingPage />} />
           <Route path="/smartphones/" element={<WomenGarments/>} /> 
        </Routes>
      </Router>
    </div>
  );
}

export default App;
