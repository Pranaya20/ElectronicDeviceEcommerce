import React from 'react';
import HeroSection from '../Components/HeroSection';
import HeadingSection from '../Components/HeadingSection';
import SelectionItems from '../Components/SelectionItems';

function LandingPage() {
  return (
    <div>
         <HeroSection/>
        <HeadingSection/>
        <SelectionItems/>
    </div> 
  )
}

export default LandingPage