import React,{useState, useEffect} from 'react';
import { Wrapper } from '../Assets/Style/WomensGarmentsStyle';
import _map from "lodash/map";
import axios from 'axios';

function WomenGarments() {
    const url = 'https://dummyjson.com/products/';
    const [data, setData] = useState([]);
    console.log("data:-",data.products);

    const fetchInfo = () => {
        return axios.post(url).then((res) => setData(res.data));
      };
    
      useEffect(() => {
        fetchInfo();
      }, []);
  return (
    <Wrapper>
           <div className="gallery-grid-container--XDZDt">
              <div className="gallery-grid--qTRRj">
                {_map(data.products, (items, key) => (
                  <div key={key} /*style={{padding:"5px"}}*/>
                    <div className="promotion-container--QYED5">
                      <div className="item-container--C33E5">
                           <img className="image-container--bbSdi" src={items?.images[0]} alt="image" style={{width:"300px",height:"300px"}} />
                      </div>
                      <div className="itemData--IKVIy">
                        <div className="itemTags--WmwVA"></div>
                        <div className="titleAndWishlist--Tg1kt">
                          <div className="itemTitle--FVCGg">
                            
                          </div>
                          <div className="rootRippleButton--_LSi0 btnWishListWrapper--TqAmW wishlistWrapper--gzgPy newDesign--fyE5Q" >
                           
                              
                          </div>
                        </div>
                        <div className="bottom--A0oq4"><div className="--TX9tV gallitemPriceContainereryItem--VpIo6 newGalleryStyle--TVlx4">
                          <div className="priceWrapper--AOyAi newGalleryStyle--TVlx4">
                            <div className="priceContainer--xSe_e">
                                <div className="price--EotcN" data-qa="price2-itemPage_Desktop">
                                    {items?.title}
                                   
                                </div>
                                <div className="price--EotcN" data-qa="price2-itemPage_Desktop">
                                    {items?.description}
                                </div>
                                <div className="price--EotcN" data-qa="price2-itemPage_Desktop">
                                ${items?.price}
                                </div>
                            </div>
                          </div>
                        </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div> 
       {/* <div class="product-container">
   
        {_map(data,(items, key)=>(
             <div class="product-card">
            <div class="product-image">
            <span class="discount-tag">50% off</span>
            <img src={items.image} class="product-thumb" alt=""/>
            <button class="card-btn">add to whislist</button>
        </div>
        <div class="product-info">
            <h2 class="product-brand">brand</h2>
            <p class="product-short-des">a short line about the cloth..</p>
            <span class="price">$20</span><span class="actual-price">$40</span>
        </div>
        </div>
        ))}
       
    
    +7 more cards
</div> */}
      
       

    </Wrapper>
  )
}

export default WomenGarments







