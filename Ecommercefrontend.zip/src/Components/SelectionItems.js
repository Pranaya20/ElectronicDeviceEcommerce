import React,{ useEffect} from 'react';
import Api from "../Services/Api";
import { Wrapper } from '../Assets/Style/SelectionItemsStyle';
import {PRESENTOPTION, SHOPITEMS} from "../Common/Constant";
import { Link } from "react-router-dom";
import _map from "lodash/map";

function SelectionItems() {
  useEffect(() => { 
   
      return Api.fetchDataCetagoryWise()
        // .then((response) => {
        //   if (response?.data?.data?.diamonds_by_query?.items) {
        //     setLoading(false);
        //   }
        //   if (page) {
        //     setData(d=>[...d, ...response?.data?.data?.diamonds_by_query?.items]);
        //   } else {
        //     setData(response?.data?.data?.diamonds_by_query?.items);
        //   }
        // })
        // .catch((error) => {
        //   setTimeout(() => {
        //     setLoading(false)
        //   }, 4000)
        //   console.log({ error });
        // });
    });
  return (
    <Wrapper>
      <div className='option-div'>
         {_map(PRESENTOPTION,(items, key)=>(
          <div className='option-box-div'>
             <img src={items.images} alt='items-image' className='option-image-div'/>
             <Link to={{pathname:items.redirect, state:{id: 1, name: 'sabaoon', shirt: 'green'}}}><div className='presentation-image'><span>{items.name}</span></div></Link>
          </div>
         ))}
      </div>
      <div className='option-div'>
      {_map(SHOPITEMS,(items, key)=>(
          <div className='option-box-div'>
             <img src={items.images} alt='items-image' className='option-image-div'/>
             <div className='presentation-image'>{items.name}</div>
          </div>
         ))}
      </div>
    </Wrapper>
  )
}

export default SelectionItems