import React from 'react';
import { Wrapper } from '../Assets/Style/HeadingSectionStyle';

function HeadingSection() {
  return (
    <Wrapper>Shop  by Category</Wrapper>
  )
}

export default HeadingSection