import React from "react";
import Garments from "../Assets/Image/mainImage.png";
import {Wrapper} from "../Assets/Style/HeroSectionStyle";
import {COLLECTION ,STYLE ,EVERPIECE} from "../Common/Constant";

function HeroSection() {
  return (
    <Wrapper>
      <div className="image-container">
        <img src={Garments} className="garments-icon" alt="cental Hero"/>
        <div className="builder-block">
        <div>{COLLECTION}</div>
        <div>{STYLE}</div>
        <div>{EVERPIECE}</div>
        </div>
      </div>
    </Wrapper>
  );
}

export default HeroSection;
